@extends('templates.frontend')
@section('content')
<div class="card card-style">
    <div class="content">
        <div class="d-flex">
            <div>
            </div>
            <div>
                <h4 class="">ABOUT</h4>
                <hr>

                <h2 class="mb-0 pt-1">RIZKI FAHREZI MAULANA</h2>
                <p class="color-highlight text-uppercase font-11 mt-n1 mb-3">DEVELOPER</p>
            </div>
        </div>
        <p>
            Selamat datang di Muthia Smart School!

            Aplikasi ini adalah wujud dari tekad kami untuk memudahkan Anda dalam memantau kinerja siswa. Dengan Muthia Smart School.
        </p>
    </div>
</div>
@endsection